#!/bin/bash

# Demenu run
dmenu_run -i -nb '#0C0F13' -nf '#ED0322' -sb '#ED0322' -sf '#0C0F13' -fn 'NotoMonoRegular:bold:pixelsize=14'
