alias clone="git clone --depth 1"
alias gmit="bash ~/.scripts/git-licence-MIT.sh"
alias gp="bash ~/.local/bin/git-auto-push.sh"
